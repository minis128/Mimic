
package com.example.volumebuttonanimation

import android.media.AudioManager
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.volumebuttonanimation.ui.theme.VolumeButtonAnimationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        setContent {
            VolumeButtonAnimationTheme {
                var isVisible by remember { mutableStateOf(false) }
                var volumeLevel by remember { mutableStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)) }
                val scope = rememberCoroutineScope()

                // UI Layout
                Box(modifier = Modifier.fillMaxSize()) {
                    AnimatedVisibility(visible = isVisible) {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .background(Color.Gray, shape = CircleShape)
                                .align(Alignment.Center)
                        ) {
                            Text(
                                text = "$volumeLevel",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }
                }

                // React to volume key presses
                this@MainActivity.onKeyDown { keyCode ->
                    if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                            volumeLevel = (volumeLevel + 1).coerceAtMost(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
                        } else {
                            volumeLevel = (volumeLevel - 1).coerceAtLeast(0)
                        }
                        isVisible = true
                        scope.launch {
                            delay(2000)
                            isVisible = false
                        }
                    }
                }
            }
        }
    }

    private fun ComponentActivity.onKeyDown(callback: (Int) -> Unit) {
        this.setContentView(R.layout.activity_main)
        this.window.decorView.setOnKeyListener { _, keyCode, _ ->
            callback(keyCode)
            true
        }
    }
}
